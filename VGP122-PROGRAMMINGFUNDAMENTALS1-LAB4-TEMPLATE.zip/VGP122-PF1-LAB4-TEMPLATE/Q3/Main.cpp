/* Write a program to count the number of vowels and consonants in a character array, using
pointers. */