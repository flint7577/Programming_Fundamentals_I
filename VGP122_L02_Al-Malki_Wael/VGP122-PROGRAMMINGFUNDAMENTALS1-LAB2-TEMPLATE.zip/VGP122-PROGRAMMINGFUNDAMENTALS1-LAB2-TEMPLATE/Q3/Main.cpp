/* Write an application that finds the smallest of several integers. Assume that the
first value read specifies the number of values to input from the user. */